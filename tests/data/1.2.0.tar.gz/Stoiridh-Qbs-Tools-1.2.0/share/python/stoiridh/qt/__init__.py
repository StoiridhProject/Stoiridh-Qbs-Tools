# -*- coding: utf-8 -*-
from . import quick
from .documentation import Documentation, HtmlDirectoryNotFound
